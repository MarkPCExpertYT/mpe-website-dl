To install, run setup.exe, NOT File Wiper.application.

This is a file wiper I made in Visual Basic. This took me much time to make.
!!!WARNING!!! Use at your own risk, it wipes ANYTHING without any confirmation.

Thanks for downloading from my website! :)